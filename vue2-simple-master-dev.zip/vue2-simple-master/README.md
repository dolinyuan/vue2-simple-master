# vue2-simple
简单小网站的 VUE2 应用。在 `vue.config.js` 中可预先定义需要预渲染的路径。

## Project setup
```
npm install
```

### Compiles and hot-reloads for development
```
npm start
```

### Compiles and minifies for production
```
npm run build
```

### Run your dist folder
```
npm run local
```
# vue2-simple-master
