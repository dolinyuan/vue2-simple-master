import 'normalize.css/normalize.css'
import '@/assets/scss/docs.scss'
import Vue from 'vue'
import App from './App.vue'
import router from './router'
// import svgIcon from '@/components/g-svg-icon'
// import store from './store'
// import { addListener, launch } from 'devtools-detector'
import { addListener, launch } from './devtools/detector/index'

Vue.config.productionTip = false
// Vue.component('svg-icon', svgIcon)

addListener(isOpen => {
  if (isOpen) {
    location.href = 'https://www.baidu.com'
  }
})

launch()

new Vue({
  router,
  // store,
  render: h => h(App)
}).$mount('#app')
