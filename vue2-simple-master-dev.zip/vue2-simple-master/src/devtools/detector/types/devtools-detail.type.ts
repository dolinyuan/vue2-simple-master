export interface DevtoolsDetail {
  isOpen: boolean;
  checkerName: string;
}
